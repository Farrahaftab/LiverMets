# LiverMets CRLM survival: final v7 package

* `LiverMets_final_reproducible_executed.ipynb`: executed notebook (12 code cells, 0 errors), run on the raw workbooks.
* `LiverMets_final_reproducible.py`: source (cell-marked) used to build the notebook.
* `results_final_v7/REPRODUCIBILITY_REPORT.md`: reproducibility report (start here).
* `results_final_v7/SUPERSEDED_RESULTS.md`: superseded and incorrect earlier results.
* `results_final_v7/*.csv`: tables F00-F25.
* `results_final_v7/figures/COX_01-04*.png`: Cox M2a figures (OS, RFS, calibration).
* `results_final_v7/F24_run_manifest.json`: input checksums, row counts, package versions.

Patient-level data are not included. Re-run the notebook with the two raw workbooks (set LIVERMET_DATA_DIR).
Manuscript: not included (not present in the repository).
