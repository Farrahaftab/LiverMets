# LiverMets CRLM survival: v8 package

* Revised_manuscript_v7.docx: revised manuscript (draft for supervisor review; checklists, author confirmations and citation checks outstanding).
* Change_summary_v7_to_v8.md: exactly what changed from v7 to v8.
* Remaining_issues_for_supervisor.md: open decisions and confirmations.
* LiverMets_final_reproducible_v8_executed.ipynb: executed notebook (15 code cells, 0 errors) run on the raw workbooks.
* LiverMets_final_reproducible.py: notebook source.
* results_final_v7/: all tables and figures. Primary outputs F00-F23 are unchanged from v7. Supplementary outputs F60-F68; audit in audit/; feasibility in feasibility/; investigation in investigation/.

No patient-level data are included.
